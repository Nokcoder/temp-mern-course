export const CLEAR_CART = 'CLEAR_CART';
export const REMOVE = 'REMOVE';
export const INCREASE = 'INCREASE';
export const DECREASE = 'DECREASE';
export const LOADING = 'LOADING';
export const DISPLAY_ITEMS = 'DISPLAY_ITEMS';
