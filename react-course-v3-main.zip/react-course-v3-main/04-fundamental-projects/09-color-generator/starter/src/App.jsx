const App = () => {
  return <h2>Color Generator Starter</h2>;
};
export default App;
