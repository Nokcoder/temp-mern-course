const App = () => {
  return <h2>Lorem Ipsum Starter</h2>;
};
export default App;
