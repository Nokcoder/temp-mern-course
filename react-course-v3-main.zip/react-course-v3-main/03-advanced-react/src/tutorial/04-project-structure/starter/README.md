In this section, we will create all files and folders from scratch.
