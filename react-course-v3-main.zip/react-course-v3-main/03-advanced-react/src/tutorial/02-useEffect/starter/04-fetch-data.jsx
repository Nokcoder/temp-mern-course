const url = 'https://api.github.com/users';

const FetchData = () => {
  return <h2>fetch data example</h2>;
};
export default FetchData;
