import { useState } from 'react';

const ShortCircuitOverview = () => {
  return <h2>short circuit overview</h2>;
};
export default ShortCircuitOverview;
