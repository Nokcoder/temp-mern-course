const App = () => {
  return <h1>Unsplash Images Starter</h1>;
};
export default App;
